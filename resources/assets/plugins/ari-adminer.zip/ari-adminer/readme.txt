=== ARI Adminer - WordPress Database Manager ===
Contributors: arisoft
Donate link: http://wp-quiz.ari-soft.com/plugins/wordpress-adminer.html
Tags: adminer, sql, database, mysql, report, sqlite, table, postgresql, dump, backup, import, export, phpmyadmin
Requires at least: 3.4
Tested up to: 4.9.8
Stable tag: 1.1.12
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WordPress Database Management Tool based on Adminer application. Run SQL queries, import/export data, create backup. 

== Description ==

This plugin connects WordPress and [Adminer](https://www.adminer.org) database management tool. Can work with MySQL, PostgreSQL and SQLite databases.

https://www.youtube.com/watch?v=OOLfWI3L2v0

ARI Adminer supports the following features:

= Features =

* Can connect to **WordPress database** automatically

* Possible to **save** connection parameters. Enter parameters only once and next times choose only connection name to connect to DB

* Supports **20+ themes** for Adminer tool

* Can **test connection**. Populate connection fields, click "Test connection" button and the plugin shows if any errors occur

* Work in two modes: **Advanced** and **Simple**. All features for managing databases are available in advanced mode. [Adminer Editor](https://www.adminer.org/en/editor/) tool is used in simple mode , it provides limited functionality with user-friendly database data editing. Provides high-level data manipulation and suitable for common users

* Only users with selected **user roles** will have access to the plugin

* Run SQL queries, import and export data, create dump and backup

* WordPress part contains **English** and **Russian** translations, can create your own. Adminer contains more than 35 translations


More information can be found in [user's guide](http://www.ari-soft.com/docs/wordpress/ari-adminer/v1/en/index.html).

**Have any idea how to improve the plugin?** Don't hesitate to share it [here](http://www.ari-soft.com/ARI-Adminer/) and we will try to implement it in future versions of the plugin.

**Do you like the plugin and want to say about it?** Write a review and get a rating [here](https://wordpress.org/support/plugin/ari-adminer/reviews/).

**Are interested in other our WordPress plugins?** 
Check [ARI Fancy Lightbox](https://wordpress.org/plugins/ari-fancy-lightbox/) is the best lightbox plugin with social and viral features.

[ARI Stream Quiz](https://wordpress.org/plugins/ari-stream-quiz/) is WordPress Viral Quiz Builder plugin.

[Contact Form 7 MailChimp Connector](https://wordpress.org/plugins/ari-cf7-connector/) integrates CF7 with MailChimp service.


== Installation ==

1. Open 'Plugin -> Add New' screen in admin part of your WordPress site, type 'ARI Adminer' in search box and click 'Install Now' button to install the plugin or use 'Upload Plugin' button on 'Plugins -> Add New' screen to upload `ari-adminer.zip` file and install the plugin
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the 'ARI Adminer -> Run Adminer' screen to start manage databases.


== Frequently Asked Questions ==

= Is a detailed documentation available? =
Sure, it is available [here](http://www.ari-soft.com/docs/wordpress/ari-adminer/v1/en/index.html).


== Screenshots ==
1. Run Adminer page
1. Connections page
1. Settings page
1. Adminer - Advanced mode
1. Adminer - Simple mode


== Changelog ==

= 1.1.12 =
* Update Adminer to v. 4.6.3

= 1.1.11 =
* Fix bug: editing.js file is not loaded in Adminer

= 1.1.10 =
* Update Adminer to v. 4.6.2
* Update .htaccess file. Thank you to KZeni (https://wordpress.org/support/topic/conflict-sucuri-security-wp-content-folder-hardening-breaks-ari-adminer/)

= 1.1.9 =
* Better PHP 7.2.x support

= 1.1.8 =
* Installer improved: if utf8mb4 charset is not supported by database, use utf8

= 1.1.7 =
* Show quick icon on frontend part and take into account role of current user

= 1.1.6 =
* Add 'Show quick icon' parameter to plugin settings

= 1.1.5 =
* Fix bug: show Move/Copy buttons when only one database is available

= 1.1.4 =
* Bug fix

= 1.1.3 =
* Possible to select default connection

= 1.1.2 =
* Update Adminer to v. 4.3.1
* Check installed PHP extensions for PostgreSQL

= 1.1.1 =
* Improve installer

= 1.1.0 =
* Encrypt database passwords

= 1.0.8 =
* Update Adminer to v. 4.3.0 

= 1.0.7 =
* Fix bug: javascript files are not loaded and search and other functions don't work

= 1.0.6 =
* Add .htaccess file to allow execution of Adminer wrapper to avoid "Forbidden" error

= 1.0.5 =
* Compatible with WordPress 3.x

= 1.0.4 =
* Improve uninstall routine

= 1.0.3 =
* Russian translation is added

= 1.0.2 =
* Ask confirmation on connections bulk delete

= 1.0.1 =
* Added PostgreSQL support

= 1.0.0 =
* Initial release


== Upgrade Notice ==

= 1.1.12 =
* Update Adminer to v. 4.6.3

= 1.1.11 =
* Fix bug: editing.js file is not loaded in Adminer

= 1.1.10 =
* Update Adminer to v. 4.6.2

= 1.1.9 =
* Better PHP 7.2.x support

= 1.1.8 =
* Installer improved: if utf8mb4 charset is not supported by database, use utf8

= 1.1.7 =
* Show quick icon on frontend part and take into account role of current user

= 1.1.6 =
* Add 'Show quick icon' parameter to plugin settings

= 1.1.5 =
* Fix bug: show Move/Copy buttons when only one database is available

= 1.1.4 =
* Bug fix

= 1.1.3 =
* Possible to select default connection

= 1.1.2 =
* Update Adminer to v. 4.3.1 
* Check installed PHP extensions for PostgreSQL

= 1.1.1 =
* Improve installer

= 1.1.0 =
* Encrypt database passwords

= 1.0.8 =
* Update Adminer to v. 4.3.0

= 1.0.7 =
* Fix bug: javascript files are not loaded and search and other functions don't work

= 1.0.6 =
* Add .htaccess file to allow execution of Adminer wrapper to avoid "Forbidden" error

= 1.0.5 =
* Compatible with WordPress 3.x

= 1.0.4 =
* Improve uninstall routine

= 1.0.3 =
* Russian translation is added

= 1.0.2 =
* Ask confirmation on connections bulk delete

= 1.0.1 =
* Added PostgreSQL support

= 1.0.0 =
* No need any action