<?php
namespace Ari\Controllers;

class Display_Options extends Controller_Options {
    public $view_path = '';
}
