<?php
define( 'ADMINER_WRAPPER_TYPE', 'editor' );

require_once dirname( __FILE__ ) . '/wrapper.php';
