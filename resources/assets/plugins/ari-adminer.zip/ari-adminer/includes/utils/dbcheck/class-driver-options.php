<?php
namespace Ari_Adminer\Utils\Dbcheck;

use Ari\Utils\Options as Options;

class Driver_Options extends Options {
    public $db_name  = '';

    public $host = '';

    public $user = '';

    public $pass = '';
}
