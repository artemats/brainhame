<div class="custom-cursor cc-1">
  <svg class="svg-inline--fa fa-long-arrow-alt-right fa-w-14" aria-hidden="true" data-prefix="fal"
       data-icon="long-arrow-alt-right" role="img"
       xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg=""
       style="visibility: hidden; opacity: 0;">
    <path fill="currentColor" d="M288 160.649V239H12c-6.627 0-12 5.373-12 12v10c0 6.627 5.373 12 12 12h276v78.348c0 29.388 34.591 43.268 54.627 23.231l96-95.952c12.496-12.497 12.497-32.757 0-45.255l-96-95.955C322.65 117.44 288 131.15 288 160.649zM416 256l-96 96V160l96 96z"></path>
  </svg>
  <!-- <i class="fal fa-long-arrow-alt-right"></i> -->
</div>

<div class="custom-cursor cc-2"></div>
