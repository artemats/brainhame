{{--
  Template Name: Contacts
--}}

@extends('layouts.app')
@section('content')
    {{--==================================--}}

    <div data-vue="render-page">
      @include('pages.contacts.contacts')
    </div>

    {{--==================================--}}
@endsection
