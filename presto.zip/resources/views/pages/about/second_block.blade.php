<section class="section second_block">
  <div class="section-inner">
    <div class="block-wrapper">
      <div class="image-wrapper">
        <img src="{{ $second_block->image }}" />
      </div>
      <div class="block-description section-description">
        <div class="row">
          <div class="col-7">
            {!! $second_block->description !!}
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
