<div class="section single-post-content">
  <div class="section-inner">
    <div class="row">
      <div class="col-xl-9">
        @content
      </div>
    </div>
  </div>
</div>
